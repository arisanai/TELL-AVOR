from flask import Flask, render_template, request, redirect, url_for, flash
import datetime

app = Flask(__name__)
app.secret_key = 'supersecretkey'  # Change this for security

# Fake Database
messages = []

@app.route("/", methods=["GET", "POST"])
def home():
    if request.method == "POST":
        message_text = request.form["message"]
        ip_address = request.remote_addr
        timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        messages.append({"text": message_text, "ip": ip_address, "time": timestamp})
        flash("Message sent!", "success")

    return render_template("index.html", messages=messages)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
